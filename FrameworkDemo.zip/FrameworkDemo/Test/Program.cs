﻿using FrameworkDemo.Pages;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameworkDemo
{
    public class Program 
    {
        [TestFixture]

        class CreateProfiles : Global.Base
        {
            //Test case 1: Share a Skill
            [Test]
            public void ShareSkill()
            {
                //Start the create profile test
                test = extent.StartTest("Sharing the skill");

                //Creating a Class
                ShareSkill obj = new ShareSkill();

                //Creating Method
                obj.SharingSkill();

            }

            //Test case 2: Edit a Listing
            [Test]
            public void EditList()
            {
                //Start the create profile test
                test = extent.StartTest("Edit a List");

                //Creating a Class
                ShareSkill obj = new ShareSkill();

                //Creating Method
                obj.EditListings();

            }

            //Test case 3: Deactivating a Listing
            [Test]
            public void DeleteList()
            {
                //Start the delete list test
                test = extent.StartTest("Delete a List");

                //Creating a Class
                ShareSkill obj = new ShareSkill();

                //Creating Method
                obj.DeleteListings();

            }
        }

    }
}
