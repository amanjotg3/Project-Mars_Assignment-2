﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace FrameworkDemo.Pages
{
    public class ScenarioClassDefinitions: Global.Base
    {
        [BeforeScenario]
        public void BeforeScenario()
        {
            Inititalize();
            Global.GlobalDefinitions.driver.Manage().Window.Maximize();
        }
        

        [AfterScenario]
        public void AfterScenario()
        {
            TearDown();
        }
    }
}
