﻿using System;
using TechTalk.SpecFlow;
using AutoItX3Lib;
using FrameworkDemo.Global;
using NUnit.Core;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System.Threading;
using static NUnit.Core.NUnitFramework;

namespace FrameworkDemo
{
    [Binding]
    public class AddCertificationsSteps :Pages.ScenarioClassDefinitions
    {
        [Given(@"I click on add certification button")]
        public void GivenIClickOnAddCertificationButton()
        {
            //Click on Certifications tab
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[1]/a[4]")).Click();
        }

        [When(@"I fillin the details for certifications")]
        public void WhenIFillinTheDetailsForCertifications()
        {

            //Click on Add New button in Certifications
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/table/thead/tr/th[4]/div")).Click();

           //Finding Certificate textbox
           IWebElement cert= Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[1]/div/input"));

            //Enter value in Certificate textbox
            cert.SendKeys("FSC");

            //Finding Certificate From textbox
            IWebElement CertFrom= Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[2]/div[1]/input"));

            //Enter value in Certificate From textbox
            CertFrom.SendKeys("India");

            //Click on Year of certification dropdown 
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[2]/div[2]/select")).Click();
            
          //Select the year of certification value from the dropdown 
          Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[2]/div[2]/select/option[6]")).Click();

          //Click on Add Certifications Button
          Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[3]/input[1]")).Click();
        }

        [Then(@"the details for certifications should be added")]
        public void ThenTheDetailsForCertificationsShouldBeAdded()
        {
            //Start the Add certification test
            Base.test = Base.extent.StartTest("Add Certifications");

            //Verification  
            string message = Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/table/tbody/tr/td[1]")).Text;
            string ActualMessage = "FSC";

            //Explicit Wait
            Thread.Sleep(2000);

            //Verification  
            try
            {
                if (message == ActualMessage)
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Certificate added");
                    Global.SaveScreenShotClass.SaveScreenshot(Global.GlobalDefinitions.driver, "Certification");
                }
                else
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Certification not added");
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

    }
}
