﻿using System;
using TechTalk.SpecFlow;
using AutoItX3Lib;
using FrameworkDemo.Global;
using NUnit.Core;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System.Threading;
using static NUnit.Core.NUnitFramework;

namespace FrameworkDemo 
{
    [Binding]
    public class AddEducationSteps 
    {
        [Given(@"I click on add education button")]
        public void GivenIClickOnAddEducationButton()
        {
            //Click on education tab
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[1]/a[3]")).Click();
        }

        [When(@"I fillin the details for education")]
        public void WhenIFillinTheDetailsForEducation()
        {

            //Click on Add New button in Education
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/table/thead/tr/th[6]/div")).Click();

           //Finding College textbox
          IWebElement colg= Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[1]/div[1]/input"));

            //Enter text in college textbox
            colg.SendKeys("ABC");
            
          //Click on Country dropdown button
          Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[1]/div[2]/select")).Click();
            
          //Select the country value from the dropdown
          Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[1]/div[2]/select/option[66]")).Click();

          //Click on Title dropdown button
          Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[1]/select")).Click();

          //Select the title value from the dropdown
          Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[1]/select/option[7]")).Click();

          //Finding Degree textbox
          IWebElement deg= Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[2]/input"));

            //Enter text in degree textbox
            deg.SendKeys("CSE");

        //Finding Year of graduation dropdown button
        Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[3]/select")).Click();
            
        //Select the year of graduation value from the dropdown
        Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[3]/select/option[11]")).Click();

        //Click on Add Education Button
        Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[3]/div/input[1]")).Click();
        }

        [Then(@"the details for education should be added")]
        public void ThenTheDetailsForEducationShouldBeAdded()
        {
            //Start the Add education test
            Base.test = Base.extent.StartTest("Add Education");

            //Verification
            string message = Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/table/tbody/tr/td[2]")).Text;
            string ActualMessage = "ABC";

            //Explicit Wait
            Thread.Sleep(200);

            //Verification  
            try
            {
                if (message == ActualMessage)
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Education added");
                    Global.SaveScreenShotClass.SaveScreenshot(Global.GlobalDefinitions.driver, "Education");
                }
                else
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Education not added");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
