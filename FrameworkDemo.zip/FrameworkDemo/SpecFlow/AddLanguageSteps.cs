﻿using System;
using TechTalk.SpecFlow;
using AutoItX3Lib;
using FrameworkDemo.Global;
using NUnit.Core;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System.Threading;
using static NUnit.Core.NUnitFramework;

namespace FrameworkDemo
{
    [Binding]
    public class AddLanguageSteps
    {
        [Given(@"I press add language button")]
        public void GivenIPressAddLanguageButton()
        {
            //Click on language tab
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/table/thead/tr/th[3]/div")).Click();
        }     

        [When(@"I fillin the details for language")]
        public void WhenIFillinTheDetailsForLanguage()
        {
            //Finding Add Language textbox
           IWebElement langText= Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[1]/input"));

            //Sending value to language textbox
            langText.SendKeys("Punjabi");
            
            //Select Choose Language Level dropdown button
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[2]/select")).Click();

            //Select the Language Level value from the dropdown
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[2]/select/option[4]")).Click();

            //Click Add button
            Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[3]/input[1]")).Click();
            Thread.Sleep(200);
        }

        [Then(@"the details for language should be added")]
        public void ThenTheDetailsForLanguageShouldBeAdded()
        {
            //Start the Add Language test
            Base.test = Base.extent.StartTest("Add Language");

            //Verification
            string message = Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/table/tbody/tr/td[1]")).Text;
            string ActualMessage = "Punjabi";

            //Explicit Wait
            Thread.Sleep(2000);

            //Verification  
            try
            {
                if (message == ActualMessage)
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Language added");
                    Global.SaveScreenShotClass.SaveScreenshot(Global.GlobalDefinitions.driver, "Language");
                }
                else
                {
                    Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Language not added");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
