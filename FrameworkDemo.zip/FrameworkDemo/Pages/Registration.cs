﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace FrameworkDemo.Global
{
    internal class Registration
    {
        public Registration()
        {
            PageFactory.InitElements(GlobalDefinitions.driver, this);
        }


        //Initialize or finding the elements

        //Define Join button
        [FindsBy(How = How.XPath, Using = "//*[@id='home']/div/div/div[1]/div/button")]
        private IWebElement joinbtn { set; get; }

        //Finding the firstname textbox
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/form/div[1]/input")]
        private IWebElement Firstname { get; set; }

        //Finding the Lastname textbox
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/form/div[2]/input")]
        private IWebElement Lastname { get; set; }

        //Finding Email Address textbox
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/form/div[3]/input")]
        private IWebElement email { get; set; }

        //Finding password field
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/form/div[4]/input")]
        private IWebElement Password { get; set; }

        //Finding confirm Password field
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/form/div[5]/input")]
        private IWebElement ConfirmPswd { get; set; }

        //Finding checkbox  
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/form/div[6]/div/div/input")]
        private IWebElement chkbox { get; set; }

        //Finding Join2 Button
        [FindsBy(How = How.XPath, Using = "//*[@id='submit-btn']")]
        private IWebElement joinbtn2 { get; set; }

        internal void Regsteps()
        {
            //Start the Register test
            Base.test = Base.extent.StartTest("User Registration");

            //Populating the Excel sheet
            ExcelLib.PopulateInCollection(Config.Resource.ExcelPath, "Registration");
            GlobalDefinitions.wait(500);

            //Navigate to the Url
            GlobalDefinitions.driver.Navigate().GoToUrl(ExcelLib.ReadData(2, "Url"));
            GlobalDefinitions.wait(500);

            //Click on Join button
            joinbtn.Click();
            GlobalDefinitions.wait(500);

            //Enter Firstname
            Firstname.SendKeys(ExcelLib.ReadData(2, "FirstName"));
            GlobalDefinitions.wait(500);

            //Enter lastname
            Lastname.SendKeys(ExcelLib.ReadData(2, "LastName"));
            GlobalDefinitions.wait(500);

            //Enter the Email Address
            email.SendKeys(ExcelLib.ReadData(2, "Email Address"));
            GlobalDefinitions.wait(500);

            //Enter the password
            Password.SendKeys(ExcelLib.ReadData(2, "Password"));
            GlobalDefinitions.wait(500);

            //Enter the confirm password
            ConfirmPswd.SendKeys(ExcelLib.ReadData(2, "Confirm Password"));
            GlobalDefinitions.wait(500);

            //Selecting checkbox
            chkbox.Click();
            GlobalDefinitions.wait(500);

            //Click on join button
            joinbtn2.Click();
            GlobalDefinitions.wait(500);

            //Screenshot
            Global.SaveScreenShotClass.SaveScreenshot(GlobalDefinitions.driver, "RegistrationPage");

            //Reports
            Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Registration successfull");


        }
    }
}