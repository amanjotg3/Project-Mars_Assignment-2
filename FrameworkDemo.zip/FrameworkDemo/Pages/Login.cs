﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using RelevantCodes.ExtentReports;
using System.Threading;

namespace FrameworkDemo.Global
{
    internal class Login
    {

        //Create a Constructor
        public Login()
        {
            PageFactory.InitElements(Global.GlobalDefinitions.driver, this);
        }

        //Define Sign In button
        [FindsBy(How = How.XPath, Using = "//*[@id='home']/div/div/div[1]/div/a")]
        private IWebElement SignIn { set; get; }
        
        //Define the Email textBox
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/div[1]/div/div[1]/input")]
        private IWebElement Username { set; get; }

        //Define the Password textBox
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/div[1]/div/div[2]/input")]
        private IWebElement Password { set; get; }

        //Define the Login Button
        [FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div/div[1]/div/div[4]/button")]
        private IWebElement LoginBtn { set; get; }

     
        internal void LoginSteps()
        {
            //Start the Add address test
            Base.test = Base.extent.StartTest("User Login");

            //Populate in collection
            ExcelLib.PopulateInCollection(Global.Base.ExcelPath, "LoginPage");

            //Navigate to Url
            GlobalDefinitions.driver.Navigate().GoToUrl(ExcelLib.ReadData(2, "Url"));
            GlobalDefinitions.wait(500);

            //Click on Sign In button
            SignIn.Click();
            GlobalDefinitions.wait(500);

            //Enter Username 
            Username.SendKeys(ExcelLib.ReadData(2, "UserName"));

            //Enter Password 
            Password.SendKeys(ExcelLib.ReadData(2, "Password"));

            //Click on login Button
            LoginBtn.Click();

            Thread.Sleep(1000);
            //Verification
            string message = Global.GlobalDefinitions.driver.FindElement(By.XPath("//*[@id='account-profile-section']/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div[1]")).Text;
            string ActualMessage = Global.ExcelLib.ReadData(2,"ActualMsg");

            //Explicit Wait
            Thread.Sleep(2000);

            //Verification           
            if (message == ActualMessage)
            {
                // Console.WriteLine("Login Successful");
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Pass, "Login Successfull");
                Global.SaveScreenShotClass.SaveScreenshot(Global.GlobalDefinitions.driver, "HomePage");
            }
            else
            {
                Base.test.Log(RelevantCodes.ExtentReports.LogStatus.Fail, "Login Unsuccessfull");
                //Console.WriteLine("Login Unsuccessful");
            }
                   
         }
    }
}